package dep

type Interface interface {
	N([]byte)
}
